
typedef float DTYPE;
#define SIZE 1024 		/* SIZE OF DFT */
void dft(DTYPE real_sample[1024], DTYPE imag_sample[1024],DTYPE real_op[1024], DTYPE imag_op[1024]);

